﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineFanShop.Klase
{
    public class StanjeSkladista
    {
        public int IDproizvod { get; set; }
        public string nazivProizoda { get; set; }
        public string velicina { get; set; }
        public int kolicina { get; set; }
    }
}
