﻿
namespace OnlineFanShop.Forme
{
    partial class frmUrediOdabranuPonudu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNaziv = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbVrsta = new System.Windows.Forms.ComboBox();
            this.cmbFransiza = new System.Windows.Forms.ComboBox();
            this.cmbVelicina = new System.Windows.Forms.ComboBox();
            this.btnUrediPonudu = new System.Windows.Forms.Button();
            this.btnObrisiPonudu = new System.Windows.Forms.Button();
            this.btnOdustani = new System.Windows.Forms.Button();
            this.numCijena = new System.Windows.Forms.NumericUpDown();
            this.txtKolicina = new System.Windows.Forms.TextBox();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            ((System.ComponentModel.ISupportInitialize)(this.numCijena)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNaziv
            // 
            this.txtNaziv.Location = new System.Drawing.Point(217, 25);
            this.txtNaziv.Margin = new System.Windows.Forms.Padding(4);
            this.txtNaziv.Name = "txtNaziv";
            this.txtNaziv.Size = new System.Drawing.Size(311, 22);
            this.txtNaziv.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.Location = new System.Drawing.Point(558, 57);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "Cijena jednog proizvoda:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(558, 26);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(224, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Dostupna količina proizvoda:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(30, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Veličina proizvoda:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(30, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Franšiza proizvoda:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(30, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "Vrsta proizvoda:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(30, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Naziv proizvoda:";
            // 
            // cmbVrsta
            // 
            this.cmbVrsta.FormattingEnabled = true;
            this.cmbVrsta.Location = new System.Drawing.Point(217, 55);
            this.cmbVrsta.Name = "cmbVrsta";
            this.cmbVrsta.Size = new System.Drawing.Size(311, 24);
            this.cmbVrsta.TabIndex = 45;
            // 
            // cmbFransiza
            // 
            this.cmbFransiza.FormattingEnabled = true;
            this.cmbFransiza.Location = new System.Drawing.Point(217, 87);
            this.cmbFransiza.Name = "cmbFransiza";
            this.cmbFransiza.Size = new System.Drawing.Size(311, 24);
            this.cmbFransiza.TabIndex = 46;
            // 
            // cmbVelicina
            // 
            this.cmbVelicina.FormattingEnabled = true;
            this.cmbVelicina.Location = new System.Drawing.Point(217, 118);
            this.cmbVelicina.Name = "cmbVelicina";
            this.cmbVelicina.Size = new System.Drawing.Size(311, 24);
            this.cmbVelicina.TabIndex = 47;
            // 
            // btnUrediPonudu
            // 
            this.btnUrediPonudu.Location = new System.Drawing.Point(167, 189);
            this.btnUrediPonudu.Name = "btnUrediPonudu";
            this.btnUrediPonudu.Size = new System.Drawing.Size(136, 50);
            this.btnUrediPonudu.TabIndex = 48;
            this.btnUrediPonudu.Text = "Uredi ponudu";
            this.btnUrediPonudu.UseVisualStyleBackColor = true;
            this.btnUrediPonudu.Click += new System.EventHandler(this.btnUrediPonudu_Click);
            // 
            // btnObrisiPonudu
            // 
            this.btnObrisiPonudu.Location = new System.Drawing.Point(481, 189);
            this.btnObrisiPonudu.Name = "btnObrisiPonudu";
            this.btnObrisiPonudu.Size = new System.Drawing.Size(136, 50);
            this.btnObrisiPonudu.TabIndex = 49;
            this.btnObrisiPonudu.Text = "Obriši ponudu";
            this.btnObrisiPonudu.UseVisualStyleBackColor = true;
            this.btnObrisiPonudu.Click += new System.EventHandler(this.btnObrisiPonudu_Click);
            // 
            // btnOdustani
            // 
            this.btnOdustani.Location = new System.Drawing.Point(810, 189);
            this.btnOdustani.Name = "btnOdustani";
            this.btnOdustani.Size = new System.Drawing.Size(136, 50);
            this.btnOdustani.TabIndex = 50;
            this.btnOdustani.Text = "Odustani";
            this.btnOdustani.UseVisualStyleBackColor = true;
            this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
            // 
            // numCijena
            // 
            this.numCijena.DecimalPlaces = 2;
            this.numCijena.Location = new System.Drawing.Point(819, 67);
            this.numCijena.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numCijena.Minimum = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            this.numCijena.Name = "numCijena";
            this.numCijena.Size = new System.Drawing.Size(126, 22);
            this.numCijena.TabIndex = 51;
            this.numCijena.Value = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            // 
            // txtKolicina
            // 
            this.txtKolicina.Location = new System.Drawing.Point(819, 25);
            this.txtKolicina.Margin = new System.Windows.Forms.Padding(4);
            this.txtKolicina.Name = "txtKolicina";
            this.txtKolicina.Size = new System.Drawing.Size(127, 22);
            this.txtKolicina.TabIndex = 43;
            // 
            // helpProvider1
            // 
            this.helpProvider1.HelpNamespace = "OnlineFanShopHelp.chm";
            // 
            // frmUrediOdabranuPonudu
            // 
            this.ClientSize = new System.Drawing.Size(1092, 287);
            this.Controls.Add(this.numCijena);
            this.Controls.Add(this.btnOdustani);
            this.Controls.Add(this.btnObrisiPonudu);
            this.Controls.Add(this.btnUrediPonudu);
            this.Controls.Add(this.cmbVelicina);
            this.Controls.Add(this.cmbFransiza);
            this.Controls.Add(this.cmbVrsta);
            this.Controls.Add(this.txtKolicina);
            this.Controls.Add(this.txtNaziv);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.helpProvider1.SetHelpKeyword(this, "180");
            this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.TopicId);
            this.Name = "frmUrediOdabranuPonudu";
            this.helpProvider1.SetShowHelp(this, true);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.frmUrediOdabranuPonudu_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.numCijena)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtNaziv;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbVrsta;
        private System.Windows.Forms.ComboBox cmbFransiza;
        private System.Windows.Forms.ComboBox cmbVelicina;
        private System.Windows.Forms.Button btnUrediPonudu;
        private System.Windows.Forms.Button btnObrisiPonudu;
        private System.Windows.Forms.Button btnOdustani;
        private System.Windows.Forms.NumericUpDown numCijena;
        private System.Windows.Forms.TextBox txtKolicina;
        private System.Windows.Forms.HelpProvider helpProvider1;
    }
}