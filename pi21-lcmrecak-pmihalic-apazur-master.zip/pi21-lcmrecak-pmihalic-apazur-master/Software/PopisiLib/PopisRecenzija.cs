﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineFanShop.Klase
{
    public class PopisRecenzija
    {
        public string korisnickoIme { get; set; }
        public int ocjena { get; set; }
        public string komentar { get; set; }
    }
}
