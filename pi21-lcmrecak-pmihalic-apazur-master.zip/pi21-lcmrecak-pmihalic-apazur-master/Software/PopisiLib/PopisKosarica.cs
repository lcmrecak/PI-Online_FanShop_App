﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineFanShop.Klase
{
    public class PopisKosarica
    {
        public int ID_korisnik { get; set; }
        public int ID_ponuda { get; set; }
        public string naziv { get; set; }
        public int? kolicina { get; set; }
        public int? popust { get; set; }
        public double? cijena { get; set; }
        
    }
}
